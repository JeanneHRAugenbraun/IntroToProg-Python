#-------------------------------------------------#
# Title: Assignment 5
# Dev:   Jeanne H R Augenbraun
# Date:  04/29/2018
# Desc: Create a To do text file using a Python dictionary
# ChangeLog: (Who, When, What)
# JHRA, 04/30/2018, Attempted to get code to work
#-------------------------------------------------#



'''
This project is like to the last one, but this time The ToDo file will contain two columns of data (Task, Priority)
which you store in a Python dictionary. Each Dictionary will represent one row of data and these rows of data are added to a
Python List to create a table of data.

1.	Create a text file called Todo.txt using the following data:
Clean House,low
Pay Bills,high

2.	When the program starts, load each row of data from the ToDo.txt text file into a Python dictionary.
(The data will be stored like a row in a table.)
Tip: You can use a for loop to read a single line of text from the file and then place the data into a new dictionary object.

3.	After you get the data in a Python dictionary, Add the new dictionary “row” into a
Python list object (now the data will be managed as a table).

4.	Display the contents of the List to the user.

5.	Allow the user to Add or Remove tasks from the list using numbered choices. Something like this would work:

    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program

6.	Save the data from the table into the Todo.txt file when the program exits.

'''

#  NOTE:  This is program is based on Assignment05_Starter.py written by RRoot 11/2/2016

# Create a text file called Todo.txt using the following data:
# Clean House,low
# Pay Bills,high


objFileName = "C:\\Users\\Jeanne\\Desktop\\_PythonClass\\python foundations UW\\module 5\\Todo.txt"
strData = ""
dicRow = {}
lstTable = []

# Step 1 - Load data from a file
# When the program starts, load each "row" of data
# in "ToDo.txt" into a python Dictionary.
# Add the each dictionary "row" to a python list "table"

objFile = open(objFileName, "r")
for line in objFile:
    strData = line.split(",")
    dicRow = {"Task": strData[0].strip(), "Priority": strData[1].strip()}
    lstTable.append(dicRow)
objFile.close()

# Step 2 - Display a menu of choices to the user
while (True):
    print("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 4] - "))
    print()  # adding a new line

    # Step 3 - Show the current items in the table
    if (strChoice.strip() == '1'):
        for row in lstTable:
            print(row["Task"] + " -- " + row["Priority"])
        continue

    # Step 4 - Add a new item to the list/Table

    elif (strChoice.strip() == '2'):
        while(True):
            strTask = str(input("Enter a Task: ")).strip().capitalize()
            strPriority = str(input("Enter a Priority ('high', 'medium' or 'low'): ")).strip().capitalize()
            dicRow = {"Task": strTask, "Priority": strPriority}
            lstTable.append(dicRow)
            print("Item added to the list.")
            if (input("Type 'stop' to stop entering Tasks and Priorities, otherwise press Enter to continue. ").lower() == "stop"): break
        continue

    # Step 5 - Remove a new item to the list/Table
    elif (strChoice == '3'):
        # This is basically the code that RRoot showed in online office hours.  it does not work
        strTaskRem = (str(input("Which Task would you like to remove? ")).strip().capitalize())
        blnRemove = False
        currentRow = 0

        while(currentRow < len(lstTable)):
            if (strTaskRem == str(list(dict(lstTable[currentRow]).values())[0])):
                del lstTable[strTaskRem]
                blnRemove = True
                currentRow += 1
            else:
                print("That Task was not found in your list.")
                break
        continue

    # Step 6 - Save tasks to the ToDo.txt file
    elif (strChoice == '4'):
        while(True):
            objFile = open(objFileName, "a")
            for dicRow in lstTable:
                objFile.write(dicRow["Task"] + ", " + dicRow["Priority"] + "\n")
            objFile.close()
            print("The data was saved to a file.  Choose number 1 on the Menu to show the current data.")
            break
        continue
    elif (strChoice == '5'):
        print("Goodbye.")
        break  # and Exit the program

